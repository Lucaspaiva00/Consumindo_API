function consultaEndereco() {
    let cep = document.getElementById('cep').value;

    if (cep.length !== 8) {
        alert("CEP Inválido");
        return;
    }

    let url = "https://viacep.com.br/ws/" + cep + "/json/";

    fetch(url).then(function (response) {
        response.json().then(mostrardados)
    });

}

function mostrardados(dados) {
    let resultado = document.querySelector('#resultado');
    if (dados.erro) {
        resultado.innerHTML = "Não foi possível localizar o endereço"
    } else {
        resultado.innerHTML = `Endereço: ${dados.localidade}<p>
        </p>Bairro: ${dados.bairro}<p>
        Cep: ${dados.cep}</p>
        DDD: ${dados.dd}`
    }

}


